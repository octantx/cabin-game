# from termcolor import *
    
#     print(colored("                          -       The Cabin       -", "red", attrs=["bold"]))
#     print(colored(f"""
#       ▄      ▄   ██▄   ▄███▄   █▄▄▄▄ ▄█▄    █▄▄▄▄ ████▄ ▄████     ▄▄▄▄▀ 
#        █      █  █  █  █▀   ▀  █  ▄▀ █▀ ▀▄  █  ▄▀ █   █ █▀   ▀ ▀▀▀ █    
#     █   █ ██   █ █   █ ██▄▄    █▀▀▌  █   ▀  █▀▀▌  █   █ █▀▀        █    
#     █   █ █ █  █ █  █  █▄   ▄▀ █  █  █▄  ▄▀ █  █  ▀████ █         █     
#     █▄ ▄█ █  █ █ ███▀  ▀███▀     █   ▀███▀    █          █       ▀      
#      ▀▀▀  █   ██                ▀            ▀            ▀             
#                           - Permanent Tribulation -
#                           -        {ver}          - 
#     """, "blue", attrs=["bold"]))